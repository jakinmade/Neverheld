/**
 * Seal kit: canonical JSON (RFC 8785, JCS), SHA-256 and Ed25519 checks.
 *
 * Plain browser features only (Web Crypto), so the same code runs in the sealed page, in the
 * offline verifier page and in Node (version 20 or later). No dependencies.
 *
 * Canonical form: object keys sorted by UTF-16 code units, no whitespace, strings and numbers
 * written as ECMAScript JSON.stringify writes them (which is what RFC 8785 specifies). Only
 * whole numbers are allowed in sealed data, so standard tools (jq -cjS) give the same bytes.
 */
export type Json = null | boolean | number | string | Json[] | {
    [key: string]: Json;
};
export declare function canonicalJson(value: unknown): string;
export declare function toHex(bytes: ArrayBuffer | Uint8Array): string;
export declare function sha256Hex(data: string | Uint8Array | ArrayBuffer): Promise<string>;
export declare function canonicalHash(value: unknown): Promise<string>;
export declare function base64ToBytes(text: string): Uint8Array<ArrayBuffer>;
/** Ed25519 check using Web Crypto. `publicKeyB64` is the raw 32-byte key in base64. */
export declare function ed25519Verify(publicKeyB64: string, signatureB64: string, message: string | Uint8Array): Promise<boolean>;
