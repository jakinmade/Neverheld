export type Evidence = {
    sealed: boolean;
    selfTestRefused: boolean;
    policyBlocksAllConnections: boolean;
    pageRequestsSinceSealing: number;
    blockedAttemptsSinceSealing: number;
    /** declared-none / declared-blocked come from the application owner and are not tested by the session. */
    workers: WorkerEvidence;
    /** A service worker runs outside the page's policy and can send whatever the page posts to it. */
    serviceWorker: "none" | "registered" | "controlling" | "not-available";
    filesFingerprinted: number;
    filesOpenedBeforeSeal: number;
    /** Long-lived connections opened before sealing and still open when it took effect. */
    connectionsOpenAtSeal: number;
    /** Attempts blocked inside the page (page-level, not browser-enforced). */
    guardBlocked: number;
    connectionAllowlist: "present" | "absent" | "not-checked";
};
export type WorkerEvidence = "declared-none" | "declared-blocked" | "not-declared" | "contradicted";
type Condition = {
    id: keyof Evidence;
    oneOf: Array<boolean | number | string>;
    failure: string;
};
type Pack = {
    id: string;
    name: string;
    question: string;
    supported: string;
    notSupported: string;
    limits: string;
};
/** The ruleset. Changing any character changes its fingerprint; bump `version` when you do. */
export declare const CONTROL_RULESET: {
    id: string;
    version: string;
    conditions: Condition[];
    workerNote: Record<string, string>;
    guardNote: {
        zero: string;
        nonZero: string;
    };
    allowlistNote: Record<string, string>;
    declarationNote: string;
    filesNote: {
        zero: string;
        nonZero: string;
    };
    blockedNote: {
        zero: string;
        nonZero: string;
    };
    sessionEvidence: string;
    notSupportedLead: string;
    commonLimits: string;
    packs: Pack[];
};
export type ControlAnswer = {
    pack: string;
    name: string;
    question: string;
    /** supported-if-declaration-holds: every observed condition held, but the answer also rests on the owner's untested worker declaration. */
    result: "supported" | "supported-if-declaration-holds" | "not-supported";
    answer: string;
    evidence: string[];
    limits: string;
};
export type ControlAnswers = {
    ruleset: string;
    rulesetVersion: string;
    rulesetFingerprint: string;
    answers: ControlAnswer[];
};
export declare function rulesetFingerprint(): Promise<string>;
/** Answers for the given evidence. Pure and deterministic apart from hashing the ruleset. */
export declare function controlAnswers(evidence: Evidence): Promise<ControlAnswers>;
export {};
