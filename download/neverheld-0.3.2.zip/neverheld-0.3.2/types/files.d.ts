export type FileSource = "file-input" | "drop" | "host";
export type FileRecord = {
    name: string;
    sha256: string;
    source: FileSource;
    openedAfterSeal: boolean;
};
/**
 * Record a file the page opened. `openedAt` is the performance.now() time the application
 * opened it; omit it only when calling at the moment of opening. Hashing runs in the browser.
 */
export declare function recordFile(file: Blob & {
    name?: string;
}, options?: {
    openedAt?: number;
    source?: FileSource;
}): void;
/** Record a fingerprint the host computed itself. `openedAt` (performance.now() at opening) is required. */
export declare function recordFingerprint(name: string, sha256: string, options: {
    openedAt: number;
}): void;
/** Watch file inputs and drops in this document. Safe to call more than once. */
export declare function observeFileInputs(): void;
/** All files recorded so far, with fingerprints. The same file chosen twice is listed once. */
export declare function recordedFiles(): Promise<FileRecord[]>;
