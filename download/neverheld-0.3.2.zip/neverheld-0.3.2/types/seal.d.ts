/**
 * Seal kit: the browser seal. Locks a web page so the browser itself refuses to let it send
 * data, and reports what has happened since.
 *
 * How it works
 * 1. Everything the page will need is loaded first (the caller's `prepare` step).
 * 2. A Content Security Policy is added to the page. The browser then refuses every fetch,
 *    upload, beacon, WebSocket and form post the page might attempt, whoever wrote the code.
 *    A policy can only ever be tightened, never removed, so the seal lasts until the tab closes.
 * 3. The seal tests itself: it makes one request that must be refused. If the browser lets it
 *    through, the seal reports "failed" and the caller must not open any file.
 * 4. From then on it counts every network request the page makes and every attempt the
 *    browser blocks, so the user can see the numbers stay at zero (the zero count).
 *
 * What it does not cover (browsers offer no policy for these): moving the whole tab to another
 * address, by a link or by a script, and browser extensions, which run outside the page's policy.
 * Requests made inside workers and service workers are not visible to the page's counter and are
 * not refused by the page's rule. The seal therefore records whether a service worker is
 * registered or in control, and how many workers the page started before and after sealing
 * (workers started after sealing can only come from blob: and take the page's rule). Workers
 * started before NEVERHELD loaded, or through a reference saved before it loaded, cannot be seen.
 *
 * No dependencies and nothing specific to one product. Moved here unchanged in behaviour from
 * EXEVVIA's lib/browser-seal.ts (v1.0.21), which now loads it from this kit.
 */
export type SealOptions = {
    /**
     * Development servers alone need eval and a hot-reload socket. Never set this in production:
     * it relaxes the seal.
     */
    development?: boolean;
};
/** The exact rule the browser is asked to enforce. */
export declare function sealPolicy(options?: SealOptions): string;
export type SealState = "open" | "sealing" | "sealed" | "failed";
export type ServiceWorkerState = "none" | "registered" | "controlling" | "not-available";
export type SealStatus = {
    state: SealState;
    /** performance.now() at the moment the seal took effect. */
    sealedAt?: number;
    /** Wall-clock time the seal took effect, for display. */
    sealedAtTime?: string;
    /** Wall-clock time the seal took effect, in milliseconds since 1970 (for tests and logs). */
    sealedAtEpoch?: number;
    /** The exact policy text placed in the page. */
    policy?: string;
    /** Network requests made by this page since sealing (should stay 0). */
    requests: number;
    /** Attempts the browser blocked since sealing. */
    blocked: number;
    /** Addresses of requests and blocked attempts, for the "check it yourself" panel. */
    log: string[];
    /** Workers (dedicated or shared) the page started after NEVERHELD loaded, before sealing. */
    workersStartedBeforeSeal: number;
    /** Workers started after sealing (blob: only, which take the page's rule). */
    workersStartedAfterSeal: number;
    /** Service worker state at sealing, kept at its worst value seen since. */
    serviceWorker?: ServiceWorkerState;
    /** WebSocket, EventSource, WebRTC or WebTransport connections opened since NEVERHELD loaded and still open when the seal took effect. */
    connectionsOpenAtSeal: number;
    /** Attempts NEVERHELD blocked inside the page after sealing (WebRTC, WebTransport, speculative or connection hints). Page-level, not browser-enforced. */
    guardBlocked: number;
    /** Whether the page was served with a Connection-Allowlist header (checked only on request). */
    connectionAllowlist: "present" | "absent" | "not-checked";
    error?: string;
};
/** A service worker can claim the page after sealing, so the state is re-read on every call. */
export declare function getSealStatus(): SealStatus;
/**
 * Track long-lived connections the page opens from now on, and block in the page, once sealed,
 * the connection kinds the browser's policy does not govern (WebRTC) or may not govern
 * (WebTransport). This is page-level blocking: code holding a reference saved before NEVERHELD
 * loaded, or using another frame's copy, is not stopped by it. A connection opened before
 * sealing and still open at sealing is recorded, because the policy does not close it.
 */
export declare function observeConnections(): void;
/** Read the page's own Connection-Allowlist response header (one request, before sealing). */
export declare function checkConnectionAllowlist(): Promise<"present" | "absent">;
/**
 * Count the workers the page starts from now on. Called when NEVERHELD loads, so that workers
 * started between loading and sealing are seen. It only counts; it never blocks a worker.
 */
export declare function observeWorkers(): void;
export declare function subscribeToSeal(listener: (value: SealStatus) => void): () => void;
/**
 * Seal the page. Safe to call many times: the first call does the work, later calls wait for it.
 * Rejects if preparation fails or the browser does not enforce the seal; the caller must then
 * not read any user file.
 */
export declare function sealPage(prepare?: () => Promise<void>, options?: SealOptions): Promise<void>;
/**
 * After a failure, allow another attempt (for example once the connection is back for the
 * preparation step). A seal that took effect can never be undone, so this only helps when the
 * failure happened before sealing.
 */
export declare function canRetrySeal(): boolean;
export declare function resetFailedSeal(): void;
