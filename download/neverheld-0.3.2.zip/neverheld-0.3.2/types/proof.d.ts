import { type ControlAnswers, type Evidence, type WorkerEvidence } from "./control-answers";
import type { SealStatus, ServiceWorkerState } from "./seal";
import type { FileRecord } from "./files";
/** Format 2: worker, service worker and file evidence are recorded separately (Nov 2026). */
export declare const PROOF_FORMAT = "seal-kit-proof/3";
/** What the application owner says about its background workers. Never tested by the session. */
export type WorkerDeclaration = "none" | "blocked" | "not-declared";
export type ReleaseInfo = {
    /** e.g. "neverheld-1.0.22+0123456789ab" */
    id: string;
    /** SHA-256 of the release file list served by the site, or null if the site did not serve one. */
    manifestSha256: string | null;
    manifestFiles: number | null;
};
export type ProofBody = {
    format: string;
    nature: string;
    application: {
        name: string;
        version: string;
        commit: string;
    };
    release: ReleaseInfo;
    seal: {
        state: "sealed";
        sealedAt: string;
        selfTest: "refused";
        policy: string;
        pageRequestsSinceSealing: number;
        blockedAttemptsSinceSealing: number;
        workers: {
            declaration: WorkerDeclaration;
            description: string;
            startedBeforeSeal: number;
            startedAfterSeal: number;
        };
        serviceWorker: ServiceWorkerState;
        connectionsOpenAtSeal: number;
        pageGuardBlockedSinceSealing: number;
        connectionAllowlist: "present" | "absent" | "not-checked";
    };
    /** How files came to be listed: observed inputs and drops, and/or the host's own records. */
    filesRecording: "observed-and-host" | "host-only";
    files: FileRecord[];
    controlAnswers: ControlAnswers;
    limits: string[];
    createdAt: string;
};
export type Proof = {
    format: string;
    body: ProofBody;
    proofHash: {
        alg: "SHA-256";
        value: string;
    };
};
export declare const PROOF_LIMITS: string[];
/** The facts the Control Answers rest on, worked out from the proof body alone. */
export declare function workerEvidence(workers: ProofBody["seal"]["workers"]): WorkerEvidence;
export declare function evidenceFromBody(body: Pick<ProofBody, "seal" | "files">): Evidence;
export type BuildProofInput = {
    status: SealStatus;
    /** Files recorded by the kit (recordedFiles()) and/or the host. */
    files: FileRecord[];
    /** True when the kit was observing file inputs and drops. */
    observedFiles?: boolean;
    application: {
        name: string;
        version: string;
        commit: string;
    };
    release: ReleaseInfo;
    workers: {
        declaration: WorkerDeclaration;
        description: string;
    };
    createdAt?: Date;
};
/** Build the proof. Throws if the page is not sealed. */
export declare function buildProof(input: BuildProofInput): Promise<Proof>;
/** The proof as written to file: canonical JSON, so the file's bytes are the same everywhere. */
export declare function proofJson(proof: Proof): string;
export type ReleaseSeal = {
    seal_format_version: string;
    canonicalization: string;
    record: Record<string, unknown> & {
        key_id: string;
        release?: {
            id: string;
            manifest_sha256: string;
            manifest_files: number;
        };
    };
    content_hash: {
        alg: string;
        value: string;
    };
    signature: {
        alg: string;
        key_id: string;
        signed_message: string;
        value_b64: string;
    };
    timestamps: Array<Record<string, string>>;
};
/** `unverified`: present but not checked by this verifier; shown as such, never as passed. */
export type Check = {
    name: string;
    ok: boolean;
    detail: string;
    unverified?: boolean;
};
/** Check a format-2 release seal. The public key must come from the published location, never the file. */
export declare function verifyReleaseSeal(seal: ReleaseSeal, publicKeyB64: string): Promise<{
    valid: boolean;
    checks: Check[];
}>;
export type VerifyOptions = {
    /** The signed release seal published with the release (optional). */
    releaseSeal?: ReleaseSeal;
    /** The published release public key (raw Ed25519, base64). Required with releaseSeal. */
    publicKeyB64?: string;
    /** The release file list as served or published (optional). */
    manifestText?: string;
};
/**
 * Four separate questions, never collapsed into one "verified":
 * proof self-consistency, signed release authenticity, independent timestamp, session attestation.
 */
export type Assurance = {
    proofConsistent: boolean;
    release: "authentic" | "not-checked" | "failed";
    independentTimestamp: "not-verified";
    sessionAttestation: "not-provided";
};
export type VerifyResult = {
    valid: boolean;
    releaseChecked: boolean;
    checks: Check[];
    assurance: Assurance;
};
/** Check a proof offline. Returns every check made, in order; `valid` only if all passed. */
export declare function verifyProof(input: unknown, options?: VerifyOptions): Promise<VerifyResult>;
/** Fetch the release file list the site serves (call before sealing). */
export declare function fetchReleaseInfo(url: string, id: string): Promise<ReleaseInfo>;
